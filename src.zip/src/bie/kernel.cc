/**
 * @file kernel.cc
 *
 * @author David S. Kammer <kammer@cornell.edu>
 *
 * @date creation: Mon Oct 09 2017
 * @date last modification: Mon Oct 09 2017
 *
 * @brief 
 *
 * @section LICENSE
 *
 * MIT License
 * Copyright (c) 2017 David S. Kammer 
 *
 */
#include "kernel.hh"

/* -------------------------------------------------------------------------- */
Kernel::Kernel() {
}

/* -------------------------------------------------------------------------- */
Kernel::~Kernel() {
}
